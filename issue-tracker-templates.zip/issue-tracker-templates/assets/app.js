document.addEventListener("click",e=>{
 const t=e.target;
 if(t.classList.contains("js-del"))t.closest("tr").remove();
 if(t.classList.contains("js-add")){const i=t.closest(".input-group").querySelector("input"),b=t.closest("fieldset").querySelector("tbody");
  if(i.value.trim()){b.insertAdjacentHTML("beforeend",`<tr><td>${i.value.trim()}</td><td></td><td class="text-end"><button type="button" class="btn btn-sm btn-outline-secondary js-del">Delete</button></td></tr>`);i.value=""}}
});
const $=id=>document.getElementById(id);
const cl=$("clauses");
if(cl){$("addClause").onclick=e=>{e.preventDefault();cl.tBodies[0].appendChild(cl.tBodies[0].lastElementChild.cloneNode(true))};
 $("removeClause").onclick=e=>{e.preventDefault();const b=cl.tBodies[0];if(b.rows.length>1)b.deleteRow(-1)}}
if($("wzNext")){const S=[...document.querySelectorAll(".wz-step")];let i=0;
 const show=()=>{S.forEach((s,n)=>s.classList.toggle("d-none",n!==i));$("wzTitle").textContent=`New Project Wizard (Step ${i+1} of 9)`;
  $("wzBar").style.width=((i+1)/9*100)+"%";$("wzBack").classList.toggle("invisible",i===0);$("wzNext").classList.toggle("d-none",i===8);$("wzFin").classList.toggle("d-none",i!==8)};
 $("wzNext").onclick=()=>{i++;show()};$("wzBack").onclick=()=>{i--;show()};
 $("catAdd").onclick=()=>{const v=$("catIn").value.trim();if(v){$("catSel").add(new Option(v));$("catIn").value=""}};
 $("catDel").onclick=()=>{const s=$("catSel");if(s.selectedIndex>=0)s.remove(s.selectedIndex)};
 const mv=(a,b)=>[...$(a).selectedOptions].forEach(o=>$(b).add(o));
 $("toSel").onclick=()=>mv("allU","selU");$("toAll").onclick=()=>mv("selU","allU")}
